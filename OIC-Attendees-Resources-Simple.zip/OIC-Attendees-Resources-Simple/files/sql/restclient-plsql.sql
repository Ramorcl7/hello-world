
declare

	lv_api VARCHAR2(3000) := 'http://api.mathjs.org/v4/?expr=10*5';
	lv_wallet_loc VARCHAR2(500); 
	lv_wallet_pass VARCHAR2(500);
	l_http_request utl_http.req;
	l_http_response utl_http.resp;

	lv_http_response_text varchar2(32767);
	lc_http_response_clob clob;
	lv_http_response_buffer varchar2(32767);
begin
  l_http_request := utl_http.begin_request(lv_api, 'GET', 'HTTP/1.1');
  UTL_HTTP.SET_HEADER(l_http_request, 'User-Agent', 'Mozilla/5.0');
  
 l_http_response := utl_http.get_response(l_http_request);
 dbms_output.put_line('response code ' || l_http_response.status_code);
 dbms_lob.createtemporary(lc_http_response_clob, true, 2);
 dbms_lob.open(lc_http_response_clob, dbms_lob.lob_readwrite);
 begin
 loop
   utl_http.read_text(l_http_response, lv_http_response_buffer, 32767);
   dbms_lob.writeappend(lc_http_response_clob, length(lv_http_response_buffer), lv_http_response_buffer);
 end loop;
 utl_http.end_response(l_http_response);
 exception
   when utl_http.end_of_body then
     utl_http.end_response(l_http_response);
 end;
 lv_http_response_text := dbms_lob.substr(lc_http_response_clob, 32767, 1);
 dbms_lob.freetemporary(lc_http_response_clob);
  
  
 DBMS_OUTPUT.PUT_LINE(lv_http_response_text);
end;
/ 