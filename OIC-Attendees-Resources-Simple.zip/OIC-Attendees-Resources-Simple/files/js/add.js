function add ( param1, param2 ) {
  var retValue = param1 + param2;
  return retValue;
}