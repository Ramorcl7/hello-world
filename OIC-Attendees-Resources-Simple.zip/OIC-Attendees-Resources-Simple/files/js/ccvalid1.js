function validate1 ( ccnumber ) {
  var status='INVALID';
  
  if (ccnumber=='1234-1234-1234-1234' || ccnumber=='4321-4321-4321-4321' )
	  status='VALID';
  
  return status;
  
}